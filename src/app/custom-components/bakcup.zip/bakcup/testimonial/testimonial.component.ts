import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrls: ['./testimonial.component.scss']
})
export class TestimonialComponent implements OnInit {

  testimonial_arrow_l = "./../../assets/images/arrow-left.png";
  testimonial_arrow_r = "./../../assets/images/arrow-right.png";
  testimonial_image = "./../../assets/images/person_one.png";
  testimonial_content = "I now know exactly what the other party is saying. Before ClearCaptions, I  couldn’t understand a lot of what the other party was saying, and that made conversations difficult.";

  constructor() { }

  ngOnInit() {
  }

}
