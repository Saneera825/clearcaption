import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-service-banner',
  templateUrl: './web-service-banner.component.html',
  styleUrls: ['./web-service-banner.component.scss']
})
export class WebServiceBannerComponent implements OnInit {

  webServiceBannerHeading = "ClearCaptions Web Service ";
  webServiceBannerDetail ="Take ClearCaptions with you, our Web Service can be used to place calls and view captions on your computer’s monitor";
  webServiceBannerBtnL ="Register";
  webServiceBannerBtnR ="Login";


  constructor() { }

  ngOnInit() {
  }

}
