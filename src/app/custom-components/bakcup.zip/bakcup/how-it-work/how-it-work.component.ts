import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-it-work',
  templateUrl: './how-it-work.component.html',
  styleUrls: ['./how-it-work.component.scss']
})
export class HowItWorkComponent implements OnInit {
// how it work banner
  // ccBannerImg = "./../../assets/images/how_it_work_banner.png";
  ccBannerText = "How it Works";
  // ccWork
  ccWorkImage = "./../../assets/images/ccWork_img.png";
  ccWorkHeading = "How ClearCaptions Works";
  ccWorkDetail = "Similar to captioned television, ClearCaptions uses advanced technology and a communications assistant to provide near real-time written captions of what callers say.The captioning service provided by ClearCaptions is free and paid through a fund administered by the Federal Communications Commission. ClearCaptions is available as a home phone, mobile app and through a web portal.";
  ccWorkLink = "ClearCaptions is available as a home phone, mobile app and through a web portal."

  // ccFree
  ccFreeHeading = "Why is ClearCaptions Free";
  ccFreeDetail = `ClearCaptions is a free service is supported through the federal government’s Interstate Telecommunications Relay Service fund.

  This fund is established to fulfill the mandate of the Americans with Disabilities Act (ADA) to provide functionally-equivalent communications to people with a medically recognized with a hearing loss. `;
  ccFreeButton = "Read more";

  // ccEligible
  ccEligibleHeading = "Am I Eligible";
  ccEligibleDetail = `ClearCaptions is only made available to individuals who have a medically recognized hearing disability necessitating their use of the service. To qualify for the ClearCaptions service you must have a medically recognized hearing disability that is certified by a qualified health professional.

In addtion to use the ClearCaptions home phone you will need a standard phone line and an internet connection.

The ClearCaptions Mobile app is available to download on IOS and Android and you will need a ClearCaptions account. `;
  ccEligibleButton = "Sign me up";


  // ccCertify
  ccCertifyHeading = "Who can Certify Me";
  ccCertifyDeatil = "ClearCaptions accepts certification of hearing loss from the following health professionals:";
  ccCertifyListItems=["Audiologists","etc."];
  ccCertifyLink = "Download A Professional Certification Form and provide it to your hearing-care or healthcare professional to certify your hearing loss. ";



  constructor() { }

  ngOnInit() {
  }

}
