/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CcWebServiceTabComponent } from './cc-web-service-tab.component';

describe('CcWebServiceTabComponent', () => {
  let component: CcWebServiceTabComponent;
  let fixture: ComponentFixture<CcWebServiceTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcWebServiceTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcWebServiceTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
