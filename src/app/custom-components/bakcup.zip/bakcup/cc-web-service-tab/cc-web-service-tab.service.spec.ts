/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { CcWebServiceTabService } from './cc-web-service-tab.service';

describe('CcWebServiceTabService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CcWebServiceTabService]
    });
  });

  it('should ...', inject([CcWebServiceTabService], (service: CcWebServiceTabService) => {
    expect(service).toBeTruthy();
  }));
});
