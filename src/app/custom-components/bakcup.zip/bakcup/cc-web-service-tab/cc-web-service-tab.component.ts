import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cc-web-service-tab',
  templateUrl: './cc-web-service-tab.component.html',
  styleUrls: ['./cc-web-service-tab.component.scss']
})
export class CcWebServiceTabComponent implements OnInit {

  requirementHeading = "Requirement";
  requirementDetail = "ClearCaptions is only made available to individuals who have a medically recognized hearing    disability necessitating their use of the service. To qualify for the ClearCaptions service you must have a medically recognized hearing disability that is certified by a qualified health professional.";
  requirementListHeading = "To use ClearCaptions Ensemble, you will need:";
  requirementListItems = ["Hearing loss necessitating your use of the service","High-speed Internet connection","Landline home phone service","ClearCaptions account for captions"];
  requirementImage = "./../../assets/images/ccWebPortalRequirement.png";
  requirementBtn = "Contact us for more information";

  specification_cont;

  constructor() { }

  ngOnInit() {
  }

}
