import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { PostsService } from "./../posts/posts.service";
import { Post } from "./../posts/post";
import { PagesService } from "./../pages/pages.service";
import { Page } from "./../pages/page";

@Component({
  selector: 'app-professionals',
  templateUrl: './professionals.component.html',
  styleUrls: ['./professionals.component.scss'],
  providers: [PagesService,PostsService]
})
export class ProfessionalsComponent implements OnInit {

// BannerHeading
profBannerText = "Professionals";
profBannerBtn ="Download a brochure";

// Healthcare Professionals
profHealthcareHeading ="Healthcare Professionals";
profHealthcareDetail ="Cras justo odio, dapibus ac facilisis in, egestas eget quam. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Nullam id dolor id nibh ultricies vehicula ut id elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.";
profHealthcareBtn = "Download a professional certification form for a patient";

// Assisted Living Caregivers
profAssistedLivingHeading ="Assisted Living Caregivers";
profAssistedLivingDetail ="When you share CaptionCall, you solve a real problem in the lives of your clients or residents by helping them use the phone again with confidence. Ultimately, you are helping them to stay socially engaged for a longer, happier, healthier life.";
profAssistedLivingBtn ="Schedule a in-person demo to a clearcaptions specialist";

// Patient Eligibility
profPatientEligibilityHeading ="Patient Eligibility";
profPatientEligibilityDetail = "Cras justo odio, dapibus ac facilisis in, egestas eget quam. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Nullam id dolor id nibh ultricies vehicula ut id elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.";
profPatientEligibilityBtn = "Is my patient eligible ?";

// How to Order
profOrderHeading ="How to Order";
profOrderDetail ="When you share CaptionCall, you solve a real problem in the lives of your clients or residents by helping them use the phone again with confidence. Ultimately, you are helping them to stay socially engaged for a longer, happier, healthier life.";
profOrderLink ="To place an order Contact a ClearCaptions Specialist or Download and fill out a professional certification form";

  post:Post[];
  page:Page;
  constructor(
    private pagesService: PagesService,
    private router: Router
  ) { }

  getPage(slug){
    this.pagesService
    .getPage(slug)
    .subscribe(res =>{this.page=[0];
    });
  }

  ngOnInit() {
    this.getPage('professionals');
  }

}
