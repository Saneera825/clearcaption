import { Component, OnInit } from '@angular/core';
import {BaseService} from "../base/base.service";
import {Base} from "../base/base";
import {Router} from "@angular/router";

@Component({
  selector: 'app-navi',
  templateUrl: './navi.component.html',
  styleUrls: ['./navi.component.scss'],
  providers: [BaseService]
})
export class NaviComponent implements OnInit {

  menu: Base;
  constructor(private baseService: BaseService, private router: Router) { }
  
  getTopMenu(){
    this.baseService
      .getTopMenu()
      .subscribe(
        res => {
          this.menu = res;
         // console.log(res);
        }
      );
  }

  ngOnInit() {
    this.getTopMenu();
  }

}
