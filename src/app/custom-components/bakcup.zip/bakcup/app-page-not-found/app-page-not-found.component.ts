import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-page-not-found',
  templateUrl: './app-page-not-found.component.html',
  styleUrls: ['./app-page-not-found.component.scss']
})
export class AppPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
