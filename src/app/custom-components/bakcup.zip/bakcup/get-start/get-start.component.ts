import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-start',
  templateUrl: './get-start.component.html',
  styleUrls: ['./get-start.component.scss']
})
export class GetStartComponent implements OnInit {
  getStartImg = "./../../assets/images/ccWebPortalRequirement.png";
  getStartHeading = "Lets Get Started.. It takes 5 minutes";
  getStartDetail = "ClearCaptions is available throughout the United States for those who have difficulty hearing on the phone. ";
  getStartBtn = "Sign me up";
  constructor() { }

  ngOnInit() {
  }

}
